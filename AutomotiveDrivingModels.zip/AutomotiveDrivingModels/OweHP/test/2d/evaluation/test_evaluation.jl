include(Pkg.dir("AutomotiveDrivingModels", "test", "evaluation", "test_foldsets.jl"))
include(Pkg.dir("AutomotiveDrivingModels", "test", "evaluation", "test_fold_assigners.jl"))
include(Pkg.dir("AutomotiveDrivingModels", "test", "evaluation", "test_trajdata_segments.jl"))
include(Pkg.dir("AutomotiveDrivingModels", "test", "evaluation", "test_evaluation_data.jl"))